Vue.component('spinner', {
    template: `
<div class="loading" style="border-radius: 50px;display: block;margin: 0 auto;width: 30px;height: 30px;border: 3px solid rgba(255, 255,255, 0.2);border-top: 3px solid white;"></div>
    `
});