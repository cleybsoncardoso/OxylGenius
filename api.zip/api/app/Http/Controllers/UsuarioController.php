<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Cript;

class UsuarioController extends Controller
{
    public function all(){
        return false;
    }

    public function read(){
        return false;
    }

    public function deletar(){
        return false;
    }

    public function create(){
        return false;
    }

    public function update(){
        return false;
    }

    public function vincularFacebook(){
        return false;
    }

    public function vincularGoole(){
        return false;
    }

}
